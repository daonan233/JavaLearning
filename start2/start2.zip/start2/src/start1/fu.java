package start1;

public class fu extends ye{
    public void show()
    {
        System.out.println("show方法被调用");
    }
    public int age =40;
}
