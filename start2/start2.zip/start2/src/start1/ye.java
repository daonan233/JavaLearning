package start1;

public class ye
{   public void drink()
{
    System.out.println("ass we can");
}
}
