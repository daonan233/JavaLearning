package start1;
//                      一. 输出
/*public class test1{
	/*public static void main(String[] args){
		System. out.println("Hello World");
		System. out.println(666);
		System. out.println(true);
		System. out.println('A');
		System. out.println("ass");
		//System.out.println(null);
		 int i=1;
		 System.out.println("i:"+i);
		 int j=2;
		 System.out.println(i==j);//输出false
		 System.out.println(i=j);//输出2（i被赋值为j）
	}*/
	/*
	public static void main(String[] args)
	{
		System.out.println(a);
	}
}*///可以写中文注释
/*you can also write like this sentence */



//                二.数据类型，整数型多一个byte（-128~127），内存占用1
/*public class test1{
	public static void main(String[] args)
	{
		double d=13.14;//
		long e = 10000000000000L;//为了防止数字太大而用的是int，在long后面习惯加个L
		float a= 3.14F;//同样的，为了防止float被转换成double，在float后面加上F
		System.out.println(d);
		System.out.println(e);
		System.out.println(a);
	}
}*/



//              三.标识符，不能以数字开头，不能是关键字，区分大小写。可以以$和_组成
/*命名约定：1.小驼峰命名法（方法和变量）：一个单词首字母小写，多个单词首小后大
 *         2.大驼峰命名法（类）：每个单词首字母都大写
 */


//              四：类型转换
/*public class test1{
	public static void main(String[] args)
	{
		//自动类型转换：占内存小换占内存大的
		double d=10;
		System.out.println(d);//输出10.0
		byte b=10;
	    int c=b;
	    System.out.println(c);
	    //强制类型转换
	    int k=(int)88.88;
	    System.out.println(k);//输出88，数值丢失
	}
}*/



//              五：字符和字符串的拼接
/*public class test1{
	public static void main(String[] args) {
		char a='a';
		char b='c';
		char c=(char)(a+b);
		System.out.println(c);//输出的是(int)a+(int)b对应的char
		String d="ass";
		String e="hole";
		System.out.println(d+e);
		System.out.println("哈哈哈"+6+66);//先出现字符串，后面数字运算按照字符串连接处理
		System.out.println(1+99+"瓶酒");//先出现数字运算，就先算出结果后再连接
	}
}*/



//             六：逻辑运算符

/*public class test1{
	public static void main(String[] args)
	{
		int i=10;
		int j=20;
		int k=30;
		//& 逻辑与（有false则false）
		System .out.println((i>j)&(i>k));    //false
		//| 逻辑或 （有true则true）
		System.out.println((i<j)|(j>k));    //true
		//^ 逻辑异或 （相同为false，不同为true）
		System.out.println((i<j)^(j<k));    //false
		//! 逻辑非 （这个不用说了把。。加奇数个为否，偶数个不变，奇变偶不变）

		//短路与：&&  左边为假，右边不执行
		//短路或：|| 左边为真，右边不执行
	}
}*/



//             七：数据输入

/*//导包
import java.util.Scanner;//导包的动作出现在类定义的上面
public class test1{
	public static void main(String[] args)
	{
		//创建对象
		Scanner sc=new Scanner(System.in);//这个格式里面只有sc是变量名可以变，其他的都不能变
		//接收数据
		int i=sc.nextInt();//这个格式里面只有i是变量名，可以变，其他的都不允许变
		System.out.println("i:"+i);
		//一个案例
		int height1=sc.nextInt();
		int height2=sc.nextInt();
		int height3=sc.nextInt();
		int taller=height1>height2?height1:height2;
		int tallest=taller>height3?taller:height3;
		System.out.println("最高的是："+tallest);
	}
}
*/



//              八：分支、循环、跳转
/*import java.util.Scanner;
public class test1{
	public static void main(String[] args)
	{
		//if..else、else if 语句
		int i=110;
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		if(a==i)
			{
			  System.out.println("Right");
			  a=0;
			}
		else if(a<=i)
			System.out.println("Smaller");
		else
			System.out.println("Bigger");

		//switch语句
		int tmp= sc.nextInt();
		switch (tmp)//JDK5以后可以是枚举，JDK7以后可以是字符串
		{
		case 1:
			System.out.println(tmp);//case 和数值中间记得空格一下
			break;
		case 2:
			System.out.println(tmp);
			break;
		default:
			System.out .println("Too big!");

		}

		//for循环，和C/C++一样
		for ( int j=0;j<=100;j++)
		{
			System.out.println(j);
		}

		//while循环，和C/C++一样
		int p=10;
		while (p-->=0)
		{
			System.out.println(p);//10到-1
		}

		//do while循环
		int ad=sc.nextInt();
		do {
			ad--;
			System.out.println(ad);
		}while(ad>ad);//不管这里是不是false，一定至少会运行一次

		//跳转控制语句（continue和break，一样的用法）
	}
}*/



//                           九：Random产生随机数
/*import java.util.Random;//导包
public class test1{
	public static void main(String[] args)
	{
		Random r =new Random();//r可以变，其他不行
		int number =r.nextInt(10);//number和10可以变.10代表0~10，包括0不包括10
	    int t=10;
	    while (t-->0)
		 System.out.println("number:"+number);//这样子就是同一个随机数一直输出
	    int k=10;
	    while (k-->0)
	    {
	    	int asshole =r.nextInt(100)+1;//1~100的随机数
	    	System .out.println(asshole);//这样就是输出10个不同的随机数
	    }
	}
}*/



//                         十：数组
/*import java.util.Scanner;
public class test1{
	public static void main(String[] args)
	{
		//数组定义（两种）
		int [] arr1;//定义了一个int类型的数组，数组名为arr1（一般用这种）
		int arr2[];//定义了一个int类型的变量，变量名为arr2数组
		//数组初始化
		int[] arr3=new int [3];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<=2;i++)
		{
			arr3[i]=sc.nextInt();
			System.out.println(arr3[i]);
		}
		System.out.println(arr3);
		System.out.println(arr3[0]);
		//整个数组赋值
		int[] arr4	=arr3;
		//数组的静态初始化
		int[] arr5=new int [] {1,2,3};//一种写法
		int[] arr6={1,2,3};           //另一种写法
		System.out.println(arr6[1]);
		//数组常见操作
		int length=arr6.length;//获取数组长度
		}
}*/



//                      十一：方法（其实就是函数）
/*import java.util.Scanner;
import java.util.Random;
public class test1{
	public static void wuwu()
	{
		Random rand=new Random();
		int rands=rand.nextInt(10);
		System.out.println(rands);
		Scanner sc=new Scanner(System .in);
		String str= sc.nextLine();
		System.out.println(str);
	}
	public static void ass(int numbers)
	{
		numbers=5>numbers?5:numbers;
		System.out.println(numbers);

	}
	public static void main(String [] args)
	{
		wuwu();
		Scanner sc=new Scanner(System.in);
		int numbers=sc.nextInt();
		ass(numbers);


		int[]arr= {10,20,30};
		int maxnx=maxn(arr);
		System.out.println(maxnx);

		System.out.println("调用change方法前："+arr[1]);
		change (arr);
		System.out.println("调用change方法后："+arr[1]);
		System.out.print("没有ln就是不换行");
		System.out.print(" 你看是吧");
	}
    //方法参数传递（引用类型）
	public static void change (int[] arr)
	{
		arr[1]=200;
	}
	public static int maxn(int [] arr)
	{
		int arrLength=arr.length;
		int tmp=arr[0];
		for(int i=1;i<=arrLength-1;i++)
		  tmp=arr[i]>tmp?arr[i]:tmp;
		 return tmp;
	}
}//重载就不说了*/


//                   十二：类和对象  ->用了student和phone两个类
//类是对象的数据类型，类是具有相同属性和行为的一组对象的集合
//类是对象的抽象，对象是类的实体
/*import java.util.Scanner;
import java.util.Random;
public class test1
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		phone p=new phone();
		System.out.println(p.brand);
		System.out.println(p.price);
		p.brand="小米";
		p.price=2999;
		System.out.println(p.brand);
		System.out.println(p.price);
		p.call();
		p.sendMessage();

		//自己写一个student类
		student stu=new student();
		String schools="null";
		int ages=0;
//private的用法，在student类里面的name与studentID里面使用了
		//stu.name="daonan";不能改name，因为name已经是private
		stu.getName();
		int id=0;
		id=stu.getStudentID(id);
		System.out.println(id);
		stu.regist(schools,ages);

//this的用法，在phone类里面的phoneID处使用了
		int phone_id=sc.nextInt();
		p.setPhoneID(phone_id);
		int phoneid=p.getPhoneID();
		System.out.println("phoneID:"+phoneid);

		//构造方法（在phone类里面）
	}
}
*/



//                         十三：Api练习
//案例：用户登录
/*import java.util.Scanner;
public class test1{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String userName="daonan";
		String keyWord="2021210100";
		String tryUserName;
		String tryKeyWord;
		for(int i=0;i<=2;i++)
		{
		    tryUserName=sc.nextLine();
			tryKeyWord=sc.nextLine();
			if(tryKeyWord.equals(keyWord)&&tryUserName.equals(userName))
			//字符串的相同比较用.equals()
			{
				System.out.println("登陆成功！");
				break;
			}
			else System.out.println("密码或账号错误！还能尝试"+(2-i)+"次");
			if(i==2) System.out.println("三次错误，登陆失败！");
		}
	}
}*/


//                    十四：StringBuilder相关
/*import java.util.Scanner;
public class test1
{
	public static void main(String[] args)
	{
		//StringBuilder的创建
		StringBuilder Sb=new StringBuilder();
		System.out.println("sb:"+Sb);
		System.out.println("sb.lenght"+Sb.length());

		StringBuilder Sb2=new StringBuilder("Hello World");
		System.out.println("sb2:"+Sb2);
		System.out.println("sb2.lenght:"+Sb2.length());//空格也占一个

		//append的使用:添加数据，并返回对象本身
		Sb.append("hello");
		Sb.append("world");
		Sb.append("java");
		Sb.append(100);
		System.out.println("Sb:"+Sb);
		//append的链式编程
		Sb.append("wuwu").append("daonan").append(55);
		System.out.println("Sb:"+Sb);

		//reverse()的使用：返回相反的字符序列
		Sb2.reverse();
		System.out.println("Sb2:"+Sb2);

		//StringBuilder和String互相转换
		//public String toString()  :Sb->S
		//public StringBuilder(String s）  :S->Sb

		String s="hello";
		StringBuilder sb=new StringBuilder(s);//构造的做法
		System.out.println("sb:"+sb);

		//数组改字符串加中括号
		int[] arr= {1,2,3};
		String str=arrayToString(arr);
		System.out.println(str);

		//字符串反转升级版
		Scanner sc=new Scanner (System.in);
		String line =sc.nextLine();
		String ass=myReverse(line);
		System.out.println(ass);
	}

	private static String arrayToString(int[] arr)
	{//一个拼接的方法
		StringBuilder sb=new StringBuilder();
		sb.append("[");
		for(int i=0;i<arr.length;i++)
		{
			if(i==arr.length-1)
				sb.append(arr[i]);
			else
				sb.append(arr[i]).append(",");
		}
		sb.append("]");
		String s=sb.toString();
		return s;

	}

	public static String myReverse(String s)
	{
		return new StringBuilder(s).reverse().toString();

	}
}
*/


//                       十五：集合基础
/*import java.util.Scanner;
import java.util.ArrayList;
public class test1{
	public static void main(String[] args)
	{
		//public ArrayList();     //创建一个空的集合对象
		//public bollean add(E e);  //将指定的元素追加到此集合的末尾
		//public void add(int index,E element);//在此集合中指定位置插入指定的元素

		ArrayList<String> array =new ArrayList<String>();//创建集合

		System.out.println("array:"+array);
		//System.out.println(array.add("hello")); ->输出true
		array.add("hello");//在第0个位置上
		array.add("world");//在第一个位置上
		array.add("java");//在第二个位置上
		System.out.println("array:"+array);

		//指定位置加元素public array.add(index,element);
		array.add( 3 ,"javase");//（插入的位置（最多比当前已填写的位置多一），插入内容）
		System.out.println("array:"+array);

		//删除指定元素,返回删除是否成功
		//public boolean remover (object,o);
		System.out.println(array.remove("java"));
		System.out.println(array.remove("daonan"));

		//修改指定元素，public E.set(int index,E element);
		System.out.println(array.set(1,"wocao"));//输出被替换前的
		System.out.println("array："+array);

		//返回访问位置的元素 public E.get(int index);
		String ass=array.get(2);
		System.out.println(ass);
		System.out.println(array.get(2));

		//返回集合中的元素个数：public int size();
		int size =array.size();
		System.out.println(size);
	}
}*/



//                        十六：继承  ->用了ye、fu、zi三个类
/*public class test1 {
    //建立了fu、zi两个类
    public static void main(String[] args) {
        fu f = new fu();
        f.show();
        zi z = new zi();
        z.method();
        //接下来我们用extend关键字让zi继承fu的类（在zi类里面）
        z.show();

        //继承的好处1：提高了代码的复用性（多个类相同的成员可以放在同一个类中）
        //2：提高了代码的维护性（只要修改父类的就可以）
        //继承的弊端：类的耦合性增强了，父类子类同时变化，独立性降低


        //继承类调用顺序
        int age = z.age;//如果子类里有跟父类里一样的变量/方法，就只会调用子类的
        //顺序：子类局部范围->子类成员范围->父类成员范围->再没有就报错（不考虑父亲的父亲）
        System.out.println(age);

        //super
        //代表父类存储空间的标识（可以理解为父类对象引用），在zi类里面体现了
        //fu和zi可以有同名的方法，可以用super在zi中调用fu中同名的方法,这称为方法重写

        //另外：测试一下我们是什么编码,开始用idea的时候console会输出中文乱码qwq
        // System.out.println(System.getProperty("file.encoding"));
    }
}*/



//                        十七：导包(import)  ->用了xiushifu这个类
/*import java.util.Scanner;
import daonan.xiushifu;//导入daonan这个包里面的类xiushifu
public class test1
{
    public static void main(String[] args) {
        xiushifu xiu =new xiushifu();
       //xiu.show1();  private
       //xiu.show2();    默认
       //xiu.show3();    public
        这三个都报错
        xiu.show4();
    }
}
*/


//                      十八：权限修饰符   ->用了xiushifu、university两个类
/*import daonan.xiushifu;
import daonan.university;
public class test1
{
    public static void main(String[] args) {
        //final（最终态）->修饰成员方法，成员变量，类->不能被重写，不能再次被赋值（常量），类被final修饰就不能被子继承
        //static（静态）

        //                     1.final

        xiushifu xiu = new xiushifu();
       // xiu.xiushi=40;会报错，final修饰的值无法改变

        System.out.println("final修饰的ceshi2原:"+xiu.ceshi2);
        final xiushifu xiushi =new xiushifu();//用final修饰引用类型变量
        xiushi.ceshi2=40;
        System.out.println("final修饰的ceshi2改:"+xiushi.ceshi2);
        //为什么基本类型不能变，引用类型可以变？
        //基本类型final修饰的是值，值不能变
        //引用类型的xiushi指的是地址，final修饰的是地址，地址不能变，地址里面内容的值可以变

        //                     2.static
        //static用来表示共同的变量
        university stu1 =new university();
        stu1.name="55";
        stu1.age=20;
        stu1.university="BUPT";//这边改了，下面也会一起变，因为是static
        stu1.show();
        System.out.println("");

        university stu2=new university();
        stu2.name="daonan";
        stu2.age=19;
        stu2.show();
        System.out.println("");
        stu1.show();//这时候我们在测试一下没有static修饰的会不会因为stu2改变了导致stu1也变了，发现没有
        //静态成员方法只能访问静态成员
    }
}*/


//                         十九：多态  ->使用了animal，cat，dog三个类
//多态：同一个对象，在不同时刻表现出的不同形态
//前提和体现：1.有继承/实现关系 2.有方法重写 3.有父类引用指向子类对象
/*import duotai.animal;
import duotai.cat;
import duotai.dog;
public class test1 {
    public static void main(String[] args) {
//                     1.多态的使用

     //有父类引用指向子类对象
        animal a=new cat();
        System.out.println(a.age);//输出的是animal的成员变量
        a.eat();//执行的是cat的方法
        //System.out.println(a.weight);报错，看的是左边的(animal）里面有没有这个成员方法
        //a.playGame();同样报错

        //总结：1.成员变量编译看左边，执行看左边；2.成员方法编译看左边，执行看右边；
        //因为成员方法有重写，成员变量没有

        //多态的好处和弊端：
        //好处：提高了程序的拓展性。在定义方法的时候，使用父类型作为参数，将来在使用的时候，使用具体的子类型参与操作
        //弊端：不能使用子类的特有功能，需要使用多态中的转型

//                     2.多态的转型
        //向上转型：从子到父，父类引用指向子类对象
        //向下转型：从父到子，父类引用转为子类对象
        animal catt =new cat();//向上转型
        animal dogg =new dog();
        dogg.eat();

        cat c=(cat)catt;//向下转型，强制类型转换
        c.playGame();//这里就可以访问cat的特有方法了，和595行对比
    }
}
 */


//                     二十:抽象类
//一个没有方法体的方法应该定义为抽象方法，二类中如果有抽象方法，该类必须定义为抽象类
/*import duotai.creature;
import duotai.littleCreature;
public class test1
{
    public static void main(String[] args) {
        //我已经在creature类里定义了一个抽象方法，类和方法都要用abstract修饰
        //creature crea=new creature();抽象类没法创建对象，要用多态的方法创建对象（向上转型）
        creature crea =new littleCreature();//向上转型
        crea.sleep();//抽象类里面没有方法体，用的是littleCreature的方法
        crea.jile();//littleCreature里面没有重写jile，用的是父类（抽象类）里面的方法
    }
}*/


//                    二十一:接口
//接口
/*import jiekou.*;
import org.w3c.dom.ls.LSOutput;

//在jiekou包里的类cat继承接口jumpping时用的是implements
public class test1
{
    public static void main(String[] args) {
        //1.接口的写法

        //jumpping j = new jummping;接口不能通过普通方法实现实例化
        jumpping j = new cat();//可以使用多态的方法实现
        j.jump();

        inter i = new interImpl();
        //i.num=40;报错，接口中的变量全部视为final，不可改变

        System.out.println(i.num);
        System.out.println(i.num2);
        System.out.println(i.num3);
        System.out.println(inter.num);

        //在接口的实现类里面重写方法
        i.showshow();
        i.method();

        //2.接口和类的关系
        //类和类的关系：类和类之间，只能单继承，不能多继承
        //类和接口的关系：实现关系，可以单实现，也可以多实现，可以在继承一个类的时候同时实现多个接口
        //接口和接口的关系：继承关系，可以单继承，也可以多继承

        //这里我们用jicheng1，jicheng2.jicheng3三个接口和jichengImpl这个实现类来演示

        //接口名做形参
        jumppingOperator jo=new jumppingOperator();
        jumpping2 ju=new jumppingShiXian();
        jo.usejumpping(ju);
        //接口名做返回值
        jumpping2 j2 =jo.getJumpping2();
        j2.jump();
    }
}*/


//                       二十二:内部类
//定义：就是在一个类中定义一个类。举例：在类A的内部定义一个类B，B称为内部类
//访问特点：1.内部类可以直接访问外部类的成员，包括私有类
/*import neibulei.outer;
import neibulei.outer2;
public class test1
{
    public static void main(String[] args)
    {
       //创建内部类对象并调用方法
       //不能直接创建内部类的对象
       //格式：外部类名.内部类名 对象名 =new 外部类对象().new 内部类对象()
        //成员内部类
        outer.Inner outin=new outer().new Inner();
        outin.show();

        //局部内部类
        outer o =new outer();
        o.method3();

        //匿名内部类:存在一个类或者接口，这里的类可以是具体类也可以是抽象类
        //格式：
        //new 类名或接口名(){   比如：      new Inter(){
        //    重写方法;                     public void show() {   }
        //};                             }
        outer2 oo=new outer2();
        oo.method();
        oo.ass();
    }
}
 */


import jdk.swing.interop.SwingInterOpUtils;

import javax.net.ssl.ExtendedSSLSession;
import javax.swing.*;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
import java.io.PrintStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;


//                      二十三:常用API
//1.Math   文档地址：https://www.matools.com/api/java8
/*
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Calendar;
import java.util.SimpleTimeZone;

public  class test1 {
    public static void main(String[] args) throws ParseException {
        //public static int abs(int a);返回参数的绝对值
        System.out.println(Math.abs(88));
        System.out.println(Math.abs(-88));
        System.out.println(Math.abs(-7.21));
        System.out.println("abs----------");

        //public static double ceil (double a);返回大于等于参数的最大double值，等于一个整数
        System.out.println(Math.ceil(12.34));
        System.out.println(Math.ceil(12.56));
        System.out.println("ceil----------");

        //public static double floor (double a);返回小于等于参数的最大double值，等于一个整数
        System.out.println(Math.floor(12.34));
        System.out.println(Math.floor(12.56));
        System.out.println("floor---------");

        //public static int round(float a);四舍五入返回最接近参数的int
        System.out.println(Math.round(12.34));
        System.out.println(Math.round(12.56));
        System.out.println("round---------");

        //public static int max/min (int a ,int b);这个就不写了,其实也可以比较浮点型的
        System.out.println(Math.max(22.3,44.5));
        System.out.println(Math.min(33.6,25.1));
        System.out.println("max/min-------");

        //public static double pow (double a,double b);返回a的b次幂的值

        //public static double random();返回值为double的正值[0.0,1.0）
        System.out.println(Math.random());
        System.out.println(Math.random()*100);
        System.out.println(Math.round(Math.random()*100));
        System.out.println((int)(Math.random()*100)+1);
        System.out.println("random--------");

//2.System
        //public static void exit(int status) 终止当前运行的java虚拟机，非零表示异常终止
        //public static long currentTimeMillis() 返回当前时间（以毫秒为单位）

        // System.out.println("开始");
        //System.exit(0);
        //System.out.println("结束");


        System.out.println(System.currentTimeMillis()*1.0/1000/60/60/24/365+"年");
        long start =System.currentTimeMillis();
        int ass=0;
        for(long  i=0;i<100;i++)
        {
            System.out.println(i);
        }
        long end =System.currentTimeMillis();
        System.out.println("共耗时"+(end-start)+"毫秒");

//3.Object,调用了stu这个类，并且重写了equals和toString两个方法
        //Object是类层次结构的根，每个类都可以将Object作为超类。所有类都直接或间接的继承自该类
        //构造方法:public Object();

        //toString方法
        stu stu1=new stu();
        stu1.setName("daonan");
        stu1.setAge(30);
        System.out.println(stu1);           //start1.stu@5b6f7412,打印出哈希码
        System.out.println(stu1.toString());//start1.stu@5b6f7412
        //找到println的源码（Ctrl+B)
        //建议所有子类重写此方法（自动生成即可，fn+alt+insert）

        //equals()方法
        stu stu2=new stu();
        stu2.setName("daonan");
        stu2.setAge(30);

        System.out.println(stu1==stu2);//false,因为stu1和stu2所带的地址值不一样
        System.out.println(stu1.equals(stu2));//false,equals比的还是地址值,因此要重写。重写后为true

//Arrays
        //Arrays类包含用于操作数组的各种方法
        //public satic String toString(int[] a) 返回指定数组的内容的字符串表示形式
        int[] arr ={1,9,1,9,8,1,0};
        System.out.println("排序前:"+Arrays.toString(arr));
        Arrays.sort(arr);
        System.out.println("排序后:"+Arrays.toString(arr));

//Integer（包装一个对象中的原始类型int的值）
        System.out.println(Integer.MIN_VALUE);
        System.out.println(Integer.MAX_VALUE);

        Integer i1=new Integer(100);//已经过时的
        System.out.println(i1);//100

        Integer i2=new Integer("100");
        System.out.println(i2);//100

        //Integer i3 =new Integer("abd");
        //System.out.println(i3);不少abc


        //public static Integer valueOf(int i):返回指定的int值的Integer实例
       Integer i1=Integer.valueOf(100);
        System.out.println(i1);

        //public static Integer valueOf(String s):返回一个保存指定值的Integer对象String
        Integer i2=Integer.valueOf("100");
        System.out.println(i2);
        System.out.println("----------");

//int和String的互相转换
       //int ---String
       //第一种：简单的转换
        int number =100;
        String s1=""+number;
        System.out.println(s1);
        System.out.println("----------");

        //第二种：public static String valueOf(int i);
        String s2 =String.valueOf(number);
        System.out.println(s2);
        System.out.println("----------");

        //String ---int
        String s="100";
        //方式一:String -Integer-int
        Integer i =Integer.valueOf(s);
        System.out.println(i.intValue());//intValue方法:Integer->int
        System.out.println("----------");

        //方式二:public static int parseInt(String s)
        int yy=Integer.parseInt(s);
        System.out.println(yy);
        System.out.println("----------");

//案例:字符串种数据排序

        //用public String[] split (String regex),得到字符串中的每个数字数据
        //用public static int parseInt(String s)，把String[]种的每个元素存储到int数组众
        //把排序后的int数组中的元素进行拼接得到一个字符串，用StringBuilder来实现

        String s3="91 27 46 38 50";
       String[] strArray =  s3.split(" ");
//       for(int p=0;p<strArray.length;p++)
//       {
//           System.out.println(strArray[p]);
//       }
        int [] array =new int [strArray.length];
        for(int j=0;j<array.length;j++)
        {
            array[j]= Integer.parseInt(strArray[j]);
        }

        Arrays.sort(array);

//        for(int y=0;y<arr.length;y++)
//        {
//            System.out.println(arr[y]);
//        }

        StringBuilder sb =new StringBuilder();
        for(int w=0;w<array.length;w++)//把字符串拼接成一个
    {
        if(i==array.length-1)
            sb.append(array[w]);
        else
            sb.append(array[w]).append(" ");
    }

    String result =sb.toString();
        System.out.println("result:"+result);

//案例：自动装箱与拆箱
        //装箱：把基本数据类型转换成对应的包装类类型
        Integer ii=Integer.valueOf(100);//手动装箱
        Integer iii=100;
        //拆箱:把包装类类型转换为对应的基本数据类型
        ii=ii.intValue()+200;//自动装箱(ii.Intvalue()是手动拆箱）
        ii+=200;//自动拆箱
        System.out.println(ii);

        Integer iiii=null;
        if(iiii!=null)
        {
            iii+=300;
        }

//Data类:代表了一个特定的时间，以毫秒的精度
        //public Data();分配一个Da
        Date d1 = new Date();
        System.out.println(d1);

        //public Date(long date)：分配一个Date对象，并将其初始化为从标准基准时间起指定的毫秒数
        long date =1000*60*60;
        Date d2 =new Date(date);
        System.out.println(d2);//加了时区，差9h

        //public long getTime()获取的是日期对象从1970年1月1日00:00:00到现在的毫秒值
        Date d =new Date();
        System.out.println(d.getTime()*1.0/1000/60/60/24/365+"年");

        //public void setTime(long time)：设置时间，给的是毫秒值
        long time =1000*60*60;
        d.setTime(time);
        System.out.println(d);

        long time2=System.currentTimeMillis();
        d.setTime(time2);
        System.out.println(d);
//SimpleDateFormat类概述
        Date date1 = new Date();
        SimpleDateFormat sdf=new SimpleDateFormat();
        String sDate=sdf.format(d);
        System.out.println(sDate);

        //可以多改一个
        SimpleDateFormat sdf1 =new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        String s4=sdf1.format(date1);
        System.out.println(s4);

        //从String 到 Date
        String ss="2022-07-15 20:00:14";
        SimpleDateFormat sdf2 =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//貌似不能用汉字？2022年07月15日这样
        Date dd=sdf2.parse(ss);
        System.out.println(dd);

//Calendar类
        //Calendar为某一时刻和一组日历字段之间的转换提供了一些方法，并为操作日历字段提供了一些方法
        //Calendat提供了一个类方法getInstance用于获取calendart对象，其日历字段已使用当前日期和时间初始值
        Calendar c =Calendar.getInstance();//多态的形式

        //public int get(int field)返回给定日历字段的值
        int year1 =c.get(Calendar.YEAR);
        int month1=c.get(Calendar.MONTH)+1;//注意要加一
        int dates1=c.get(Calendar.DATE);
        System.out.println(year1+"年"+month1+"月"+dates1+"日");

        //public abstract void add(int field,int amount)根据日历的规则，将指定的时间量添加或减去给定的日历字段
        c.add(Calendar.YEAR,-3);//三年前的今天
        int year2 =c.get(Calendar.YEAR);
        int month2=c.get(Calendar.MONTH)+1;//注意要加一
        int dates2=c.get(Calendar.DATE);
        System.out.println(year2+"年"+month2+"月"+dates2+"日");
        c.add(Calendar.YEAR,3);

        //public final void set(int year,int month,int date)：设置当前日历的年月日
        c.set(2077,13,11);
        int year3 =c.get(Calendar.YEAR);
        int month3=c.get(Calendar.MONTH)+1;//注意要加一
        int dates3=c.get(Calendar.DATE);
        System.out.println(year3+"年"+month3+"月"+dates3+"日");


    }
}
*/


//                        二十四：异常
/*import java.util.Date;
import java.text.ParseException;
import java.util.function.DoubleUnaryOperator;

public class test1 {
    public static void main(String[] args) {
//        Error:严重问题，不需要处理

//        Exception:异常类，表示程序本身可以处理的问题
//        RuntimeException:在编译期是不检查的。出现问题后，需要我们回来修改代码
//        非RuntimeException:编译期就必须处理的，否则程序不能通过编译，更不能正常运行
//
//          JVM（java虚拟机，Java Virtual Machine）的默认处理方案:如果程序出现了问题，我们没有做任何处理，最终JVM会做默认的处理
//          1.把异常的名称、异常原因及异常出现的位置等信息输出在了控制台
//          2.程序停止执行

//异常处理1：  try...catch...
//        try {
//            可能出现异常的代码
//        }catch(异常类名 变量名) {
//            异常的处理代码
//        }
        System.out.println("开始");
        method();
        System.out.println("结束");
        System.out.println("--------------");
        method2();
    }

    //运行时异常：

    public static void method()  {
        try {
            int[] arr = {1, 2, 3};
            System.out.println(arr[3]);//new ArrayIndexOutOfBoundsException()，产生一个新的异常类对象
        }catch(ArrayIndexOutOfBoundsException e){
           System.out.println("你所访问的数组的索引不存在");

            //public void printStackTrace();在命令行打印异常信息在程序中出错的位置及原因
            e.printStackTrace();

            //public String getMessage();返回次throwable的详细消息字符串
            System.out.println(e.getMessage());

            //public String toString();返回此可抛出的简短描述
            System.out.println(e.toString());
        }

        //

        //编译时异常
    }public static void method2()
    {
        try {
            String s = "2077-*11-*11";
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date d = sdf.parse(s);
            System.out.println(d);
        }catch(ParseException e)
        {
            e.printStackTrace();
            System.out.println(e.toString());
            System.out.println(e.getMessage());
        }
    }

//throws异常类名，这个格式是跟在方法的括号后面的
    //如public static void method2() throws ParseException{}
    //这个只是延缓了异常的发生时间，并没有处理异常。处理异常需要用try catch

//自定义异常
//    public class 异常类名 extends Exception{
//        无参构造
//        带参构造
//    }
}
*/



//               二十五:集合进阶

import java.util.*;

public class test1 {
    public static void main(String[] args) {

//collection：史丹利集合的顶层接口，他表示一组对象，这些对象也称为Collection的元素
        //JDK不提供此接口的任何直接实现，他提供更具体的子接口（如Set和List)实现

        //创建Collection集合的对象:1.多态的方式 2.具体的实现类ArrayList
        Collection<String> c = new ArrayList<String>();
        //添加元素:boolean add(E e)
        c.add("hello");
        c.add("world");
        c.add("java");
        System.out.println(c);//说明ArrayList中重写了toString方法
        //移除指定元素：boolean remove(Object o);
        c.remove("java");
        System.out.println(c);
        //判断集合中是否存在指定的元素；boolean contains(Object o)
        System.out.println(c.contains("hello"));
        System.out.println(c.contains("java"));
        //判断集合是否为空:boolean isEmpty()
        System.out.println(c.isEmpty());
        //获取集合长度：int size()
        System.out.println(c.size());
        //清空集合中的元素 void clear();
        c.clear();
        System.out.println(c.size());

        //Collection 集合的遍历- 迭代器Iterator

        Collection<String> c2 = new ArrayList<>();
        c2.add("daonan");
        c2.add("liyuan");
        c2.add("ILY");
        //Iterator<E>itorator();返回此集合中元素的迭代器，通过集合的iterator()方法得到
        Iterator<String> it = c2.iterator();
        //E.next()返回迭代中的洗一个元素
        System.out.println(it.next());
        System.out.println(it.next());
        //boolean hasNext()：如果迭代具有更多元素，则返回true；
        while (it.hasNext())
            System.out.println(it.next());
        System.out.println(it.hasNext());

//List集合
        //有序集合（也称为序列）用户可以精确控制列表中每个元素的插入位置。用户可以通过证书索引访问元素，并搜索列表中的元素
        //与Set集合不同，列表通常允许重复的元素
        //List集合特点 1.有序：存储和去除的元素顺序一致 2.可重复：存储的元素可以重复
        List<String> list = new ArrayList<String>();
        list.add("hello");
        list.add("world");
        list.add("java");
        list.add("hello");
        System.out.println(list);

        Iterator<String> it1 = list.iterator();//遍历一下list
        while (it1.hasNext()) {
            System.out.println(it1.next());
        }
        System.out.println("----------");
        //List的add(int index,E element)、remove(int index)、set(int index,E element)、get(int index)跟其他是一样的
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
        System.out.println("----------");

//并发修改异常：实际修改集合的次数和预期修改集合的次数不同，会抛出异常
        List<String> list2 = new ArrayList<String>();

        list2.add("福建");
        list2.add("泉州");
        list2.add("永春");
        for (int i = 0; i < list2.size(); i++) {
            String s = list2.get(i);
            if (s.equals("永春")) {
                list2.add("桃城");
            }
        }
        for (int i = 0; i < list2.size(); i++) {
            System.out.println(list2.get(i));
        }
//ListInterator
        List<String> llist = new ArrayList<>();
        llist.add("helloo");
        llist.add("wworld");
        llist.add("jjava");

        //获取列表迭代器
        ListIterator<String> lit = llist.listIterator();
        while (lit.hasNext()) {
            String s = lit.next();
            if (s.equals("world")) {
                lit.add("jjavaee");
            }
        }
        System.out.println(list);

//增强for循环:简化数组和Collection集合的遍历
        //实现Iterable接口的类允许其对象称为增强型for语句的目标
        //他是JDK5之后出现的，其内部原理是一个Iterator迭代器

      //  for (元素数据类型 变量名 : 数组或Collection集合)
        //在此处使用变量即可，该变量就是元素
   // },来个简单的样例
        int[] arr ={1,2,3,4,5};
        for(int i:arr)
        {
            System.out.println(i);
        }

        List <String> list3=new ArrayList<String>();
        list3.add("kpz");//抠痞子
        list3.add("gmz");//挂马子
        list3.add("zfz");//追疯子
        list3.add("csz");//草傻子
        int k=0;
        for(String i:list3)
        {
            System.out.println("list3("+k+")="+i);
            k++;
        }

//List集合子类
//        ArrayList:底层数据结构师叔祖，查询快，增删慢
//        LinkedList:地城数据结构是链表，查询慢，增删快

    }
}


