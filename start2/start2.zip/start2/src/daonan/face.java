package daonan;

public class face {
    public static void huanying() {
        System.out.println("你好呀");
    }
}
