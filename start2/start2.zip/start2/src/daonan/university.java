package daonan;

public class university {
    public String name;
    public int age;
    public static String university="北京邮电大学";

    public void show()
    {
        System.out.println("姓名:"+name);
        System.out.println("年龄:"+age);
        System.out.println("大学:"+university);
    }

}
