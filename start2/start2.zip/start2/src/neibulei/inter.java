package neibulei;

public interface inter {
    public void show();

}
