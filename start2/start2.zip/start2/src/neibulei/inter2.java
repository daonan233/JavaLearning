package neibulei;

public interface inter2 {
    public void deep();
}
