package jiekou;

public abstract class dog implements jumpping {
    //我啥也没写
}










































//真的啥也没写
