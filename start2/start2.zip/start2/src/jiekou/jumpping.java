package jiekou;
//定义了一个接口
public interface  jumpping//
{
    public abstract  void jump();
}
