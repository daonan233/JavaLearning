package jiekou;

public class jichengImpl extends Object implements jicheng1 ,jicheng2,jicheng3 {

}
