package jiekou;

public interface jicheng3 extends jicheng1,jicheng2{
    //这里用extends哦
}
