package jiekou;

public interface jicheng2 {
}
