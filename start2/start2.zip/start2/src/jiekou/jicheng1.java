package jiekou;

public interface jicheng1 {

}
