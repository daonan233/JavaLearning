package jiekou;

public interface jumpping2 {
    void jump();

}
