package jiekou;

public class jumppingShiXian implements jumpping2 {
    @Override
    public void jump() {
        System.out.println("jumpping2重写被实现！");
    }
}
