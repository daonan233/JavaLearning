package duotai;

public class animal {
    public void eat()
    {
        System.out.println("动物吃东西");
    }

    public int age=30;

}
