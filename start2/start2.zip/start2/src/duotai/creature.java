package duotai;

public abstract  class creature {//定义一个抽象类，抽象类里面可以没有抽象方法
    public abstract  void sleep();//定义一个抽象函数，没有函数体。

    public void jile()//抽象类里面可以带普通方法
    {
        System.out.println("寄了");
    }
}
