package duotai;

public class dog extends animal{
     public int age;
     public String name;
     @Override
     public void eat()
     {
          System.out.println("狗吃骨头");
     }

}
