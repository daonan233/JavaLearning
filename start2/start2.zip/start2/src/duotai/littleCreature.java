package duotai;

public  class littleCreature extends creature{
    @Override
    public  void sleep()
    {
        System.out.println("生物睡觉");
    }
}
